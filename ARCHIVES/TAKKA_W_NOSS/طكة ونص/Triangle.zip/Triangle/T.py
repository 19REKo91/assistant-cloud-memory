import os
import io
import urllib.request
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

# 1. الإعدادات الأساسية
URL = ("https://raw.githubusercontent.com/19REKo91/"
       "assistant-cloud-memory/refs/heads/main/"
       "PROJECTS/prism-engine/runs/43238833295-full-results.csv")

OUT_DIR = "Prism_Results"
DIR_VALID = os.path.join(OUT_DIR, "Valid_Triangles")
DIR_INV = os.path.join(OUT_DIR, "Invalid_Triangles")
DIR_MISS = os.path.join(OUT_DIR, "Missing_Data")
DIR_ANALYSIS = os.path.join(OUT_DIR, "Analysis_Charts")
DPI = 200

def setup_folders():
    for d in [DIR_VALID, DIR_INV, DIR_MISS, DIR_ANALYSIS]:
        os.makedirs(d, exist_ok=True)

def load_data():
    print("Downloading data from GitHub...")
    with urllib.request.urlopen(URL) as response:
        return pd.read_csv(io.BytesIO(response.read()))

# 2. دالة رسم المثلث الصالح
def draw_valid_triangle(row, filepath):
    th1 = float(row['th1'])
    a = float(row['a'])
    b = float(row['b'])
    c = 2 * float(row['s']) - a - b
    
    # إحداثيات المثلث
    A = np.array([0.0, 0.0])
    B = np.array([c, 0.0])
    C = np.array([b * np.cos(np.radians(th1)), b * np.sin(np.radians(th1))])
    
    # النقطتان
    I = np.array([float(row['I_x']), float(row['I_y'])])
    O = np.array([float(row['O_x']), float(row['O_y'])])
    
    fig, ax = plt.subplots(figsize=(6, 6))
    
    # رسم المثلث
    triangle = np.array([A, B, C, A])
    ax.fill(triangle[:,0], triangle[:,1], alpha=0.2, color='steelblue')
    ax.plot(triangle[:,0], triangle[:,1], color='navy', lw=2)
    
    # رسم النقاط والخط الواصل
    ax.plot(I[0], I[1], 'o', color='red', markersize=10, label='I (Incenter)', zorder=5)
    ax.plot(O[0], O[1], 'o', color='green', markersize=10, label='O (Circumcenter)', zorder=5)
    ax.plot([I[0], O[0]], [I[1], O[1]], '--', color='gray', lw=1.5,
            label=f'd_IO = {float(row["d_IO"]):.4f}')
    
    # التنسيق
    ax.set_aspect('equal')
    ax.grid(True, alpha=0.3)
    title = (f"Z={int(row['Z'])} {row['sym']}  |  Class: {row['class']}\n"
             f"th1={th1:.2f}  th2={float(row['th2v']):.2f}  th3={float(row['th3v']):.2f}\n"
             f"a={a:.3f}  b={b:.3f}  c={c:.3f}")
    ax.set_title(title, fontsize=10)
    ax.legend(loc='best', fontsize=9)
    
    plt.tight_layout()
    plt.savefig(filepath, dpi=DPI)
    plt.close(fig)

# 3. دالة رسم الحالات المرفوضة أو المفقودة
def draw_status_card(row, filepath, status_type):
    fig, ax = plt.subplots(figsize=(6, 6))
    Z = int(row['Z'])
    sym = row['sym']
    
    if status_type == 'INVALID':
        text = "INVALID TRIANGLE"
        color = 'red'
        reason = f"Reason: Negative Angle (th1 = {float(row['th1']):.2f})"
    else:
        text = "MISSING SOURCE DATA"
        color = 'gray'
        reason = "Reason: Dataset has no complete density/mass input"
        
    ax.text(0.5, 0.6, text, ha='center', va='center', color=color, 
            fontsize=20, weight='bold', transform=ax.transAxes)
    ax.text(0.5, 0.4, reason, ha='center', va='center', color='black', 
            fontsize=10, transform=ax.transAxes)
    ax.set_title(f"Z={Z} {sym}", fontsize=14)
    ax.axis('off')
    
    plt.tight_layout()
    plt.savefig(filepath, dpi=DPI)
    plt.close(fig)

# 4. رسم التحليلات
def draw_analysis_charts(df):
    print("Generating analysis charts...")
    
    # الرسم الأول: d_IO vs Atomic Number
    valid_df = df[df['result_status'] == 'VALID'].copy()
    valid_df['Z'] = valid_df['Z'].astype(int)
    valid_df['d_IO'] = pd.to_numeric(valid_df['d_IO'], errors='coerce')
    
    fig, ax = plt.subplots(figsize=(15, 6))
    up = valid_df[valid_df['class'] == 'UP']
    down = valid_df[valid_df['class'] == 'DOWN']
    
    ax.scatter(up['Z'], up['d_IO'], color='royalblue', label='UP (O above I)', alpha=0.8, s=70)
    ax.scatter(down['Z'], down['d_IO'], color='darkorange', label='DOWN (O below I)', alpha=0.8, s=70)
    ax.plot(valid_df['Z'], valid_df['d_IO'], color='gray', alpha=0.3, lw=1)
    
    ax.set_xlabel('Atomic Number (Z)')
    ax.set_ylabel('Distance d_IO')
    ax.set_title('d_IO across Elements')
    ax.legend()
    ax.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(DIR_ANALYSIS, "chart_dIO_vs_Z.png"), dpi=150)
    plt.close(fig)

    # الرسم الثاني: خريطة الجدول الدوري المبسطة
    def get_period(z):
        if z <= 2: return 1
        if z <= 10: return 2
        if z <= 18: return 3
        if z <= 36: return 4
        if z <= 54: return 5
        if z <= 86: return 6
        if z <= 118: return 7
        return 8
        
    grid_df = df.copy()
    grid_df['Z_int'] = grid_df['Z'].astype(int)
    grid_df['period'] = grid_df['Z_int'].apply(get_period)
    grid_df = grid_df.sort_values('Z_int')
    grid_df['pos'] = grid_df.groupby('period').cumcount() + 1

    fig, ax = plt.subplots(figsize=(22, 6))
    for _, r in grid_df.iterrows():
        status = r['result_status']
        if status == 'VALID':
            color = 'royalblue' if r['class'] == 'UP' else ('darkorange' if r['class'] == 'DOWN' else 'gray')
        elif status == 'INVALID_TRIANGLE':
            color = 'red'
        else:
            color = 'black'
            
        ax.add_patch(plt.Rectangle((r['pos']-0.5, r['period']-0.5), 1, 1,
                     facecolor=color, edgecolor='white', lw=1))
        ax.text(r['pos'], r['period'], r['sym'], ha='center', va='center',
                fontsize=8, color='white', weight='bold')

    ax.set_xlim(0.5, grid_df['pos'].max() + 0.5)
    ax.set_ylim(grid_df['period'].max() + 0.5, 0.5)
    ax.set_aspect('equal')
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_title('Periodic Table Grid Map\nBlue=UP | Orange=DOWN | Red=INVALID | Black=MISSING', fontsize=12)
    ax.legend(handles=[
        Patch(facecolor='royalblue', label='UP'),
        Patch(facecolor='darkorange', label='DOWN'),
        Patch(facecolor='red', label='INVALID'),
        Patch(facecolor='black', label='MISSING')], loc='upper right', fontsize=10)
    
    plt.tight_layout()
    plt.savefig(os.path.join(DIR_ANALYSIS, "chart_periodic_grid.png"), dpi=150)
    plt.close(fig)

# 5. التشغيل الرئيسي
def main():
    setup_folders()
    df = load_data()
    total = len(df)
    print(f"Loaded {total} elements. Starting generation...")
    
    for i, row in df.iterrows():
        Z = int(row['Z'])
        sym = row['sym']
        status = str(row['result_status']).strip()
        fname = f"{Z:03d}_{sym}.png"
        
        if status == 'VALID':
            draw_valid_triangle(row, os.path.join(DIR_VALID, fname))
        elif status == 'INVALID_TRIANGLE':
            draw_status_card(row, os.path.join(DIR_INV, fname), 'INVALID')
        elif status == 'MISSING_SOURCE_DATA':
            draw_status_card(row, os.path.join(DIR_MISS, fname), 'MISSING')
            
        if (i + 1) % 20 == 0:
            print(f"Progress: {i + 1}/{total} elements processed...")

    draw_analysis_charts(df)
    print("\n✅ DONE! Check the folder:", OUT_DIR)

if __name__ == '__main__':
    main()